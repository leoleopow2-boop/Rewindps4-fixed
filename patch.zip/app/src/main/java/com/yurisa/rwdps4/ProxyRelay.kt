package com.yurisa.rwdps4

import yurisa.Yurisa
import java.io.IOException
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.Collections
import java.util.concurrent.Callable
import java.util.concurrent.ExecutionException
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.RejectedExecutionException

/**
 * Accepts TCP connections on [listenPort] on ALL network interfaces and pipes the
 * bytes to [targetHost]:[targetPort].
 *
 * Why this exists: the Go proxy (proxy.aar) picks its listen address with
 * ExternalIP(), which relies on net.Interfaces(). Android 11+ blocks that call for
 * apps, so the Go side silently falls back to "localhost" and only the phone itself
 * can reach the proxy; the PS4/PS5 gets "connection refused". The relay is what the
 * console actually connects to.
 */
class TcpRelay(
    private val listenPort: Int,
    private val targetHost: String,
    private val targetPort: Int
) {
    private var serverSocket: ServerSocket? = null
    private val pool: ExecutorService = Executors.newCachedThreadPool()
    private val openSockets: MutableSet<Socket> = Collections.synchronizedSet(HashSet<Socket>())

    @Volatile
    private var running = false

    /** Binds the listening socket. Throws [IOException] if the port is not available. */
    @Throws(IOException::class)
    fun start() {
        val ss = ServerSocket()
        try {
            ss.reuseAddress = true
            ss.bind(InetSocketAddress(listenPort)) // wildcard address = every interface
        } catch (e: IOException) {
            closeQuietly(ss)
            pool.shutdownNow()
            throw e
        }
        serverSocket = ss
        running = true
        pool.execute { acceptLoop(ss) }
    }

    fun stop() {
        running = false
        closeQuietly(serverSocket)
        val sockets = synchronized(openSockets) { openSockets.toList() }
        sockets.forEach { closeQuietly(it) }
        pool.shutdownNow()
    }

    private fun acceptLoop(ss: ServerSocket) {
        while (running) {
            val client = try {
                ss.accept()
            } catch (e: IOException) {
                break // server socket closed by stop()
            }
            try {
                pool.execute { handle(client) }
            } catch (e: RejectedExecutionException) {
                closeQuietly(client)
                break
            }
        }
    }

    private fun handle(client: Socket) {
        val upstream = Socket()
        openSockets.add(client)
        openSockets.add(upstream)
        try {
            upstream.connect(InetSocketAddress(targetHost, targetPort), CONNECT_TIMEOUT_MS)
            client.tcpNoDelay = true
            upstream.tcpNoDelay = true

            val upstreamToClient = pool.submit { pump(upstream, client) }
            pump(client, upstream)
            try {
                upstreamToClient.get()
            } catch (e: Exception) {
                // interrupted or failed: nothing more to wait for
            }
        } catch (e: Exception) {
            // target unreachable, relay stopped, ...: drop this connection
        } finally {
            closeQuietly(client)
            closeQuietly(upstream)
        }
    }

    /** Copies [src] to [dst] until EOF, then half-closes [dst]; on I/O errors tears both down. */
    private fun pump(src: Socket, dst: Socket) {
        val buffer = ByteArray(BUFFER_SIZE)
        try {
            val input = src.getInputStream()
            val output = dst.getOutputStream()
            while (true) {
                val n = input.read(buffer)
                if (n < 0) break
                output.write(buffer, 0, n)
                output.flush()
            }
            try {
                dst.shutdownOutput()
            } catch (e: IOException) {
                // already closed
            }
        } catch (e: IOException) {
            closeQuietly(src)
            closeQuietly(dst)
        }
    }

    private fun closeQuietly(socket: Socket?) {
        if (socket == null) return
        openSockets.remove(socket)
        try {
            socket.close()
        } catch (e: IOException) {
        }
    }

    private fun closeQuietly(socket: ServerSocket?) {
        try {
            socket?.close()
        } catch (e: IOException) {
        }
    }

    private companion object {
        const val CONNECT_TIMEOUT_MS = 5000
        const val BUFFER_SIZE = 16 * 1024
    }
}

/**
 * Starts/stops the whole proxy: the Go engine (listening on a private port) plus the
 * [TcpRelay] that exposes it on the port the user types into the PS4/PS5.
 *
 * Works with the proxy.aar that is already in the project, whichever address the Go
 * side ended up binding to, and also with a rebuilt aar that listens on all interfaces.
 */
object ProxyLauncher {
    private const val ENGINE_START_TIMEOUT_MS = 3000L

    private var relay: TcpRelay? = null

    /**
     * @param publicPort port the console connects to
     * @param configureEngine called after any previous run is torn down and right before the
     *        Go engine starts, to apply the selected mode (Yurisa.setMode resets on stop)
     * @throws IOException if the engine did not come up or [publicPort] cannot be bound
     */
    @Throws(IOException::class)
    fun start(publicPort: Int, configureEngine: () -> Unit) {
        offMainThread { startLocked(publicPort, configureEngine) }
    }

    fun stop() {
        offMainThread { stopLocked() }
    }

    @Synchronized
    private fun startLocked(publicPort: Int, configureEngine: () -> Unit) {
        if (relay != null) stopLocked()
        configureEngine()

        val enginePort = findFreePort()
        val engineHost = engineHost()
        Yurisa.startProxy(enginePort.toString())
        try {
            if (!waitUntilListening(engineHost, enginePort, ENGINE_START_TIMEOUT_MS)) {
                throw IOException("Proxy engine did not start")
            }
            val newRelay = TcpRelay(publicPort, engineHost, enginePort)
            newRelay.start()
            relay = newRelay
        } catch (e: Exception) {
            // Whatever went wrong, do not leave the Go engine running without a relay.
            Yurisa.stopProxy()
            throw e
        }
    }

    @Synchronized
    private fun stopLocked() {
        // Close the console's connections first so the Go side has nothing in flight
        // when it is asked to shut down.
        relay?.stop()
        relay = null
        Yurisa.stopProxy()
    }

    /**
     * Android's StrictMode makes any java.net socket call on the UI thread throw
     * NetworkOnMainThreadException. start()/stop() are called from button handlers, so the
     * work runs on a worker thread while the caller waits for the result (the same short
     * wait as before). The monitor is taken inside the worker, never by the waiting caller.
     */
    private fun <T> offMainThread(block: () -> T): T {
        val executor = Executors.newSingleThreadExecutor()
        try {
            return executor.submit(Callable<T> { block() }).get()
        } catch (e: ExecutionException) {
            throw e.cause ?: e
        } finally {
            executor.shutdown()
        }
    }

    /** Address the Go engine listens on: the same value Yurisa.startProxy() uses internally. */
    private fun engineHost(): String {
        val ip = try {
            Yurisa.externalIP()
        } catch (e: Exception) {
            null
        }
        return if (ip.isNullOrBlank() || ip == "localhost") "127.0.0.1" else ip
    }

    private fun findFreePort(): Int = ServerSocket(0).use { it.localPort }

    private fun waitUntilListening(host: String, port: Int, timeoutMs: Long): Boolean {
        val deadline = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < deadline) {
            try {
                Socket().use { it.connect(InetSocketAddress(host, port), 300) }
                return true
            } catch (e: IOException) {
                try {
                    Thread.sleep(50)
                } catch (ie: InterruptedException) {
                    Thread.currentThread().interrupt()
                    return false
                }
            }
        }
        return false
    }
}
