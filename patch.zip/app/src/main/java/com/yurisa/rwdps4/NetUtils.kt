package com.yurisa.rwdps4

import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.SocketException
import java.util.Collections

object NetUtils {

    // Interfaces a PS4/PS5 can actually reach: Wi-Fi, Wi-Fi hotspot, Ethernet, USB tethering.
    private val LAN_PREFIXES = listOf("wlan", "swlan", "softap", "ap", "eth", "usb", "rndis", "enx", "ncm")

    // Mobile data and virtual interfaces. Their addresses are not reachable from the console.
    private val NON_LAN_PREFIXES = listOf("rmnet", "ccmni", "pdp", "ppp", "tun", "dummy", "v4-", "clat", "p2p", "lo")

    /**
     * [candidates] are (interface name, IPv4 address) pairs. Prefers a Wi-Fi/Ethernet/hotspot
     * address over anything else, and mobile data/virtual interfaces only as a last resort.
     * (The old code returned whichever interface Android listed first, which is often
     * the mobile-data one when both Wi-Fi and mobile data are on.)
     */
    fun pickLanAddress(candidates: List<Pair<String, String>>): String? {
        var best: String? = null
        var bestScore = -1
        for ((name, ip) in candidates) {
            val n = name.lowercase()
            val score = when {
                NON_LAN_PREFIXES.any { n.startsWith(it) } -> 0
                LAN_PREFIXES.any { n.startsWith(it) } -> 2
                else -> 1
            }
            if (score > bestScore) {
                best = ip
                bestScore = score
            }
        }
        return best
    }

    fun findLanIpv4(): String? {
        val candidates = ArrayList<Pair<String, String>>()
        try {
            val interfaces = NetworkInterface.getNetworkInterfaces() ?: return null
            for (intf in Collections.list(interfaces)) {
                // Only filter on the address itself (as the original code did): interface
                // flags such as isUp/isLoopback are restricted on recent Android versions.
                for (addr in Collections.list(intf.inetAddresses)) {
                    if (addr is Inet4Address && !addr.isLoopbackAddress && !addr.isLinkLocalAddress) {
                        addr.hostAddress?.let { candidates.add(intf.name to it) }
                    }
                }
            }
        } catch (e: SocketException) {
            e.printStackTrace()
        }
        return pickLanAddress(candidates)
    }
}
